<?php 
class UsuarioController{
    function __construct(){}
	function index(){
		require_once('vistas/index/contenido.php');
	}
	function error(){
		require_once('vistas/index/contenido.php');
	}
 }
 ?>
