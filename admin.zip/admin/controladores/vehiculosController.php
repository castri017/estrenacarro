<?php
class VehiculosController{
    function __construct(){}


	function nuevo(){
		require_once('vistas/vehiculos/nuevo.php');
	}

	function error(){
		require_once('vistas/index/contenido.php');
	}

/*************************************************************/
/* FUNCION PARA MOSTRAR TODOS LLAMADO DESDE ROUTING.PHP*/
/*************************************************************/

	function todos() {
		$campos=Vehiculos::obtenerPagina();
		require_once 'vistas/vehiculos/todos.php';
	}



/*************************************************************/
/* FUNCION PARA MODIFICAR  LLAMADO DESDE ROUTING.PHP*/
/*************************************************************/
	function editar() {
		$id = $_GET['id'];
		$campos = Vehiculos::obtenerPaginaPor($id);
		require_once 'vistas/vehiculos/editar.php';
	}


/*************************************************************/
/* FUNCION PARA ELIMINAR  LLAMADO DESDE ROUTING.PHP*/
/*************************************************************/
	function eliminar() {
		$id = $_GET['id'];
		$res = Vehiculos::eliminarPor($id);
		if ($res){
			echo "<script>jQuery(function(){swal(\"¡Datos eliminados!\", \"Se han eliminado correctamente los datos\", \"success\");});</script>";
		}else{
				echo "<script>jQuery(function(){swal(\"¡Error al eliminar!\", \"No se han eliminado correctamente los datos\", \"error\");});</script>";
		}
		$campos = Vehiculos::obtenerPagina();
		require_once 'vistas/vehiculos/todos.php';
	}


/*************************************************************/
/* FUNCION PARA GUARDAR NUEVO REGISTRO */
/*************************************************************/
function guardar() {
//	var_dump($_FILES);

	if (isset($_FILES)){
		$cantidad= count($_FILES);
		$id_marca = $_POST['id_marca'];
		$id_modelo = $_POST['id_modelo'];
		$ruta = '../pagina/images/vehiculos/'.$id_marca."-".$id_modelo;
		$imagen_principal = $this->subir_fichero($ruta,'imagen_principal');
		$img_frontal = $this->subir_fichero($ruta,'img_frontal');
		$img_posterior = $this->subir_fichero($ruta,'img_posterior');
		$img_lateral_izq = $this->subir_fichero($ruta,'img_lateral_izq');
		$img_lateral_der = $this->subir_fichero($ruta,'img_lateral_der');
		$img_maleta = $this->subir_fichero($ruta,'img_maleta');
		$img_interna = $this->subir_fichero($ruta,'img_interna');
		$img_motor = $this->subir_fichero($ruta,'img_motor');
		$img_interior_2 = $this->subir_fichero($ruta,'img_interior_2');
		$img_ofertas = $this->subir_fichero($ruta,'img_ofertas');
		$archivos = array($imagen_principal,$img_frontal=$img_frontal,$img_posterior,$img_lateral_izq,$img_lateral_der,$img_maleta,$img_interna,$img_motor,$img_interior_2,$img_ofertas);
	}

	$variable = $_POST;

	$nuevoarreglo = array();
	extract($variable);
	foreach ($variable as $campo => $valor){
			if ($campo=="imagen2"){
				$nuevoarreglo[$campo]=$ruta_imagen;
			}else{
				$nuevoarreglo[$campo]=$valor;
			}
	}

	$campo = new Vehiculos('',$nuevoarreglo);
	$res = Vehiculos::guardar($campo,$imagen_principal,$img_frontal,$img_posterior,$img_lateral_izq,$img_lateral_der,$img_maleta,$img_interna,$img_motor,$img_interior_2,$img_ofertas);
	if ($res){
		echo "<script>jQuery(function(){swal(\"¡Datos guardados!\", \"Se han guardado correctamente los datos\", \"success\");});</script>";
	}else{
		echo "<script>jQuery(function(){swal(\"¡Erro al guardar!\", \"No se han guardado correctamente los datos\", \"error\");});</script>";
	}
	$this->show();
}


/*************************************************************/
/* FUNCION PARA ACTUALIZAR NUEVO REGISTRO */
/*************************************************************/
function actualizar() {
//	var_dump($_FILES);
		$id = $_GET['id'];
		$id_marca = $_POST['id_marca'];
		$id_modelo = $_POST['id_modelo'];
		$ruta = '../pagina/images/vehiculos/'.$id_marca."-".$id_modelo;

		if (empty($_FILES['imagen_principal']['name'])){
			$imagen_principal = $_POST['imagen_principal2'];
		} else {
			$imagen_principal = $this->subir_fichero($ruta,'imagen_principal');
		}

		if (empty($_FILES['img_frontal']['name'])){
			$img_frontal = $_POST['img_frontal2'];
		} else {
			$img_frontal = $this->subir_fichero($ruta,'img_frontal');
		}

		if (empty($_FILES['img_posterior']['name'])){
			$img_posterior = $_POST['img_posterior2'];
		} else {
			$img_posterior = $this->subir_fichero($ruta,'img_posterior');
		}
		if (empty($_FILES['img_lateral_izq']['name'])){
			$img_lateral_izq = $_POST['img_lateral_izq2'];
		} else {
			$img_lateral_izq = $this->subir_fichero($ruta,'img_lateral_izq');
		}
		if (empty($_FILES['img_lateral_der']['name'])){
			$img_lateral_der = $_POST['img_lateral_der2'];
		} else {
			$img_lateral_der = $this->subir_fichero($ruta,'img_lateral_der');
		}
		if (empty($_FILES['img_maleta']['name'])){
			$img_maleta = $_POST['img_maleta2'];
		} else {
			$img_maleta = $this->subir_fichero($ruta,'img_maleta');
		}
		if (empty($_FILES['img_interna']['name'])){
			$img_interna = $_POST['img_interna2'];
		} else {
			$img_interna = $this->subir_fichero($ruta,'img_interna');
		}
		if (empty($_FILES['img_motor']['name'])){
			$img_motor = $_POST['img_motor2'];
		} else {
			$img_motor = $this->subir_fichero($ruta,'img_motor');
		}
		if (empty($_FILES['img_interior_2']['name'])){
			$img_interior_2 = $_POST['img_interior_22'];
		} else {
			$img_interior_2 = $this->subir_fichero($ruta,'img_interior_2');
		}
		if (empty($_FILES['img_ofertas']['name'])){
			$img_ofertas = $_POST['img_ofertas2'];
		} else {
			$img_ofertas = $this->subir_fichero($ruta,'img_ofertas');
		}
		$archivos = array($imagen_principal,$img_frontal=$img_frontal,$img_posterior,$img_lateral_izq,$img_lateral_der,$img_maleta,$img_interna,$img_motor,$img_interior_2,$img_ofertas);

	$variable = $_POST;

	$nuevoarreglo = array();
	extract($variable);
	foreach ($variable as $campo => $valor){
			if ($campo=="imagen2"){
				$nuevoarreglo[$campo]=$ruta_imagen;
			}else{
				$nuevoarreglo[$campo]=$valor;
			}
	}

	$campo = new Vehiculos('',$nuevoarreglo);
	$res = Vehiculos::actualizar($id,$campo,$imagen_principal,$img_frontal,$img_posterior,$img_lateral_izq,$img_lateral_der,$img_maleta,$img_interna,$img_motor,$img_interior_2,$img_ofertas);
	if ($res){
		echo "<script>jQuery(function(){swal(\"¡Datos actualizados!\", \"Se han guardado correctamente los datos\", \"success\");});</script>";
	}else{
		echo "<script>jQuery(function(){swal(\"¡Erro al actualizar!\", \"No se han guardado correctamente los datos\", \"error\");});</script>";
	}
	$this->show();
}


/*************************************************************/
/* FUNCION PARA MOSTRAR LA PAGINA*/
/*************************************************************/
	function show(){
		$campos=Vehiculos::obtenerPagina();
		require_once 'vistas/vehiculos/todos.php';
	}


/*************************************************************/
/* FUNCION PARA SUBIR UN ARCHIVO  */
/*************************************************************/

	function subir_fichero($directorio_destino, $nombre_fichero)
	{

		if (!file_exists($directorio_destino)) {
			mkdir($directorio_destino, 0777, true);
		}

		$tmp_name = $_FILES[$nombre_fichero]['tmp_name'];
		//si hemos enviado un directorio que existe realmente y hemos subido el archivo
		if (is_dir($directorio_destino) && is_uploaded_file($tmp_name))
		{
			$img_file = $_FILES[$nombre_fichero]['name'];
			$Aleaotorio=rand(0,99999);
			$img_file=$Aleaotorio.$img_file;
			$img_type = $_FILES[$nombre_fichero]['type'];
			// Si se trata de una imagen
			if (((strpos($img_type, "gif") || strpos($img_type, "jpeg") ||strpos($img_type, "jpg")) || strpos($img_type, "png")))
			{
				//¿Tenemos permisos para subir la imágen?
				if (move_uploaded_file($tmp_name, $directorio_destino . '/' . $img_file))
				{
					$retornar = $directorio_destino . '/' . $img_file; //RETORNAMOS EL NOMBRE Y RUTA DEL FICHERO
					return $retornar;
				}
			} else {
				if (move_uploaded_file($tmp_name, $directorio_destino . '/' . $img_file))
				{
					$retornar = $directorio_destino . '/' . $img_file; //RETORNAMOS EL NOMBRE Y RUTA DEL FICHERO
					return $retornar;
				}
			}
		}
		//Si llegamos hasta aquí es que algo ha fallado
		$vacio ='';
		return $vacio;
	}

}
 ?>
