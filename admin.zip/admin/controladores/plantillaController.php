<?php
class UsuarioController {
	function __construct() {}

	function index() {
		require_once 'vistas/plantilla/plantilla.php';
	}
}
?>